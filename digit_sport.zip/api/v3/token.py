import datetime

import jwt
from django.conf import settings
from django.utils.translation import gettext_lazy as _

from core.utils.exceptions import TokenDecodeError
from user.models import UserToken


def encode_token(payload, token_type):
    # Lose reference
    payload = dict(payload)
    token_db_instance = UserToken.objects.create(type=token_type)
    payload['__id__'] = str(token_db_instance.id)
    token_db_instance.token = jwt.encode(payload, settings.SECRET_KEY, algorithm='HS256')
    token_db_instance.save()
    return token_db_instance

def decode_token(token, token_type):
    try:
        payload = jwt.decode(token, settings.SECRET_KEY, algorithms=['HS256'])
    except jwt.PyJWTError as err:
        raise TokenDecodeError(_('UserToken invalid')) from err
    try:
        token = UserToken.objects.get(pk=payload['__id__'])
    except UserToken.DoesNotExist as err:
        raise TokenDecodeError(_('UserToken invalid')) from err
    if token.type != token_type:
        raise TokenDecodeError(_('UserToken invalid'))
    if datetime.datetime.now().astimezone(datetime.timezone.utc) > token.expires_at:
        if token.type == UserToken.REGISTRATION_TOKEN:
            token.user.delete()
        token.delete()
        raise TokenDecodeError(_('UserToken expired'))
    token.delete()
    del payload['__id__']
    return payload,